print('hello world')
